// server.js 
const express = require('express'); 
const app = express();
const PORT = 3000; // Choose any port you like 

// Body parser middleware to handle form data app.use/express.urlencoded({ extended: true })); 

// Serve static files from the 'public' folder app.use(express.static('public'));

// GET request to serve the order form app.get('/', (req, res) => 
{ res.sendFile(__dirname + 'c:\Users\holyi\OneDrive\Desktop\Todi2336\Frontend-Todi');  
};
 // POST request to handle form submission 
 app.post('/submit', (req, res) => { 
    // Assuming form has fields 'item1', 'item2', 'item3' for simplicity 
const { item1, item2, item3 } = req.body;
    
    // Calculate total (You can modify this based on your form fields) 
    const total = parseInt(item1) + parseInt(item2) + parseInt(item3); 
    
    // Send back the total in the response 
    res.send(`Total: $${total}`);
 });

 // Server listening 
 app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
 });