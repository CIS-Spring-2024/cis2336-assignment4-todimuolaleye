const menuCategories = document.getElementById('menu-categories');
const menuItemsContainer = document.getElementById('menu-items');

const menuData = {
    'Breakfast': [
        { name: 'Pancakes', price: '$5', image: 'pancakes.jpg' },
        { name: 'Omelette', price: '$6', image: 'omelette.jpg' },
        { name: 'French Toast', price: '$4', image: 'french-toast.jpg' }
    ],
    'Lunch': [
        { name: 'Burger', price: '$7', image: 'burger.jpg' },
        { name: 'Sandwich', price: '$5', image: 'sandwich.jpg' },
        { name: 'Salad', price: '$6', image: 'salad.jpg' }
    ],
    'Dinner': [
        { name: 'Steak', price: '$12', image: 'steak.jpg' },
        { name: 'Pasta', price: '$8', image: 'pasta.jpg' },
        { name: 'Pizza', price: '$10', image: 'pizza.jpg' }
    ]
};

// Function to generate menu items based on category
function generateMenu(category) {
    menuItemsContainer.innerHTML = ''; // Clear existing menu items
    menuData[category].forEach(item => {
        const menuItem = document.createElement('div');
        menuItem.classList.add('menu-item');
        menuItem.innerHTML = `
            <img src=${item.image} alt=${item.name}>
            <h3>${item.name}</h3>
            <p>${item.price}</p>
        `;
        menuItemsContainer.appendChild(menuItem);
    });
}

// Event listener to handle category selection
menuCategories.addEventListener('click', (event) => {
    if (event.target.tagName === 'A') {
        const category = event.target.textContent;
        generateMenu(category);
    }
});

// Initially load the menu with the first category (Breakfast)
generateMenu('Breakfast');